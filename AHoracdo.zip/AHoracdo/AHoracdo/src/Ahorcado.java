

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.WindowConstants;


public class Ahorcado extends javax.swing.JFrame {

    public Thread t;
    public ImageIcon Vidas[];
    public ImageIcon imgs[];
    public ImageIcon Err[];
    public JButton btns[];
    public String msgs[];
    public int ran;
    public int err;
    public int min;
    public int seg;
    public int Score;
    public int V;
    public int ans;
    public String res[];
    
    public Ahorcado() {
        initComponents();
        Score =0;
        ans = 0;
        Vidas = new ImageIcon[6];
        Err = new ImageIcon[6];
        imgs = new ImageIcon[10];
        btns = new JButton[27];
        msgs = new String[10]; 
        
        //botones para las letras
        btns[1] = jButton1;
        btns[2] = jButton2;
        btns[3] = jButton3;
        btns[4] = jButton4;
        btns[5] = jButton5;
        btns[6] = jButton6;
        btns[7] = jButton7;
        btns[8] = jButton8;
        btns[9] = jButton9;
        btns[10] = jButton10;
        btns[11] = jButton11;
        btns[12] = jButton12;
        btns[13] = jButton13;
        btns[14] = jButton14;
        btns[15] = jButton15;
        btns[16] = jButton16;
        btns[17] = jButton17;
        btns[18] = jButton18;
        btns[19] = jButton19;
        btns[20] = jButton20;
        btns[21] = jButton21;
        btns[22] = jButton22;
        btns[23] = jButton23;
        btns[24] = jButton24;
        btns[25] = jButton25;
        btns[26] = jButton26;
        
       //Para colocar las imagenes con las vidas
	    Vidas[0] = new ImageIcon(getClass().getResource("Vidas1.jpg"));
        Vidas[1] = new ImageIcon(getClass().getResource("Vidas2.jpg"));
        Vidas[2] = new ImageIcon(getClass().getResource("Vidas3.jpg"));
        Vidas[3] = new ImageIcon(getClass().getResource("Vidas4.jpg"));
        Vidas[4] = new ImageIcon(getClass().getResource("Vidas5.jpg"));
        Vidas[5] = new ImageIcon(getClass().getResource("Vidas6.jpg"));
        
        //Imagenes de los errores
		Err[0] = new ImageIcon(getClass().getResource("Err0.jpg"));
        Err[1] = new ImageIcon(getClass().getResource("Err1.jpg"));
        Err[2] = new ImageIcon(getClass().getResource("Err2.jpg"));
        Err[3] = new ImageIcon(getClass().getResource("Err3.jpg"));
        Err[4] = new ImageIcon(getClass().getResource("Err4.jpg"));
        Err[5] = new ImageIcon(getClass().getResource("Err5.jpg"));
        
        //Imagenes de las palabras que salen en el juego
        imgs[0] = new ImageIcon(getClass().getResource("Dog.jpg"));
        imgs[1] = new ImageIcon(getClass().getResource("Cat.jpg"));
        imgs[2] = new ImageIcon(getClass().getResource("Boy.jpg"));
        imgs[3] = new ImageIcon(getClass().getResource("Girl.jpg"));
        imgs[4] = new ImageIcon(getClass().getResource("Mother.jpg"));
        imgs[5] = new ImageIcon(getClass().getResource("Father.jpg"));
        imgs[6] = new ImageIcon(getClass().getResource("Bird.jpg"));
        imgs[7] = new ImageIcon(getClass().getResource("Rat.jpg"));
        
        //Para que las palablars se conviertan en mayusculas y puedas solo completarse con los botones
		msgs[0] = "Dog".toUpperCase();
        msgs[1] = "Cat".toUpperCase();
        msgs[2] = "Boy".toUpperCase();
        msgs[3] = "Girl".toUpperCase();
        msgs[4] = "Mother".toUpperCase();
        msgs[5] = "Father".toUpperCase();
        msgs[6] = "Bird".toUpperCase();
        msgs[7] = "Rat".toUpperCase();
        
       //crea un evento para cada letra 
       for (int i = 1; i < 26; i++) {
            btns[i].addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    checarLetra(e);
                }
            });
        }
       //Acomoda la imagen a tamaño del label o boton que se escoja en este caso son las vidas
        Icon iconov = new ImageIcon(Vidas[0].getImage().getScaledInstance(jLabel5.getWidth(), jLabel5.getHeight(), Image.SCALE_DEFAULT ));
        jLabel5.setIcon(iconov);
       
       iniciar();
       Cronometro();
       t.start();
       
    }
    
    //funcion para comenzar los parametros del juego o iniciar una nueva partida
    public void iniciar() {
        //ERRORES EN 0
        
        
        //Muestra el score
        jLabel4.setText("Score: "+Score);
        err = 0;
        
		Icon iconoE = new ImageIcon(Err[0].getImage().getScaledInstance(jLabel1.getWidth(), jLabel1.getHeight(), Image.SCALE_DEFAULT ));
        jLabel1.setIcon(iconoE);
        jTextPane1.setText("");
        //para activar las letras del tablero
        for (int i = 1; i < 26; i++) {
            btns[i].setEnabled(true);
        }
        //genera una palabra aleatoriamente 
        ran = (int)(Math.random() * ((8 - 1) + 1));
        
        
       
        Icon icono = new ImageIcon(imgs[ran].getImage().getScaledInstance(jLabel3.getWidth(), jLabel3.getHeight(), Image.SCALE_DEFAULT ));
        jLabel3.setIcon(icono); //Ajusta la imagen al tamaño del Label
        //SEPARA EL MENSAJE POR PALABRAS
        String pal[] = msgs[ran].split(" ");
        res = new String[msgs[ran].length() + 1];
        int j = 0;
        // seran los guiones que van debajo de las letras como una separacion_
        for (String pal1 : pal) {
            for (int i = 0; i < pal1.length(); i++) {
                jTextPane1.setText(jTextPane1.getText() + "_ ");
                res[j++] = "_";
            }
            jTextPane1.setText(jTextPane1.getText() + "\n");
            res[j++] = " ";
        }
    }

    //al presionar una letra, esta se buscara si pertenece a la palabra, de lo contrario la marcara como error 
    public void checarLetra(ActionEvent e) {
        
        JButton bt = (JButton) e.getSource();
        char c[];
        //busca la letra en la palabra despues de haber sido presionada
        for (int i = 0; i < 26; i++) {
            if (bt == btns[i]) {
                //la tecla es inicializada
                c = Character.toChars(64 + i);
                //busca si la letra esta en la frase
                boolean esta = false;
                for (int j = 0; j < msgs[ran].length(); j++) {
                    if (c[0] == msgs[ran].charAt(j)) {
                        res[j] = c[0] + "";
                        esta = true;
                    }
                }
                //SI LA LETRA ESTA EN EL MENSAJE SE MUESTRA EN EL TEXTPANEL
                if (esta) {
                    
                    
                    
                    jTextPane1.setText("");
                    for (String re : res) {
                        if (" ".equals(re)) {
                            jTextPane1.setText(jTextPane1.getText() + "\n");
                        } else {
                            jTextPane1.setText(jTextPane1.getText() + re + " ");
                        }
                    }
                    //hace una comprobacion de las letras restantes y faltantes, en caso de que ya no haya letras sera ganador :D
                    boolean gano = true;
                    for (String re : res) {
                        if (re.equals("_")) {
                            gano = false;
                            break;
                        }
                    }
                    //al ser correcta se muestra un mensaje y se reinicia el juego
                    if (gano) {
                        JOptionPane.showMessageDialog(this, "Ganaste :3 ");
                        Score += 1000;
                        jLabel4.setText("Score: "+Score);
                        ans += 10;
                        Progres(ans);
                        //iniciar();
                        return;
                    }
                    //SI LA LETRA NO ESTA EN EL MENSAGE, SE INCREMENTA EL ERROR Y SE CAMBIA LA IMAGEN
                } else {
                    Score -=100;
                    jLabel4.setText("Score: "+Score);
                    Icon iconoE = new ImageIcon(Err[++err].getImage().getScaledInstance(jLabel1.getWidth(), jLabel1.getHeight(), Image.SCALE_DEFAULT ));
                    jLabel1.setIcon(iconoE);
                    
                    //SI SE LLEGA A LOS 5 ERRORES ENTONCES SE PIERDE EL JUEGO Y SE MANDA EL MENSAGE DE:
                    if (err == 5) {
                        JOptionPane.showMessageDialog(this, "Intenta con otra palabra la respuesta es: \n" + msgs[ran]);
                        V ++;
                        Vidas(V);
                        //iniciar();
                        return;
                    }
                }
                //esta es la linea que desactiva las letras despues de ser usadas :3
                bt.setEnabled(false);
                break;
            }
        }
    }
    //Funcion que recrea un cronometro
    public  void Cronometro(){
      t = new Thread(new Runnable() {
            @Override
            public void run() {
                int centesima =0,segundo=0,minuto=0,hora=0;
                
                
            while (true){
 
                try {
                    Thread.sleep(10);
                } catch (InterruptedException ex) {}
 
                jLabe4.setText(minuto+":"+segundo);
                
                jLabel4.setText("Score: "+ (Score-segundo));
                /*jLcentesima.setText(""+centesima);
                jLsegundo.setText(""+segundo);
                jLminuto.setText(""+minuto);
                jLhora.setText(""+hora);*/
 
                 centesima++;
                if (centesima>=99){
                    centesima = 0;
                    segundo++;
                }
                if (segundo>=60){
                    segundo = 0;
                    minuto++;
                }
 
                if (minuto>=60){
                    minuto = 0;
                    hora++;
                }
                if (hora>=24){
                   centesima =0;
                   segundo = 0;
                   minuto =0;
                   hora =0;
                }
 
            }
 
 
            }
        });   
    
    }
    //Cada vez ue se falle se restara una vida que cambiara de dependiendo del numero de fallas
    public void Vidas(int V){
          
        Icon iconov = new ImageIcon(Vidas[V].getImage().getScaledInstance(jLabel5.getWidth(), jLabel5.getHeight(), Image.SCALE_DEFAULT ));
        jLabel5.setIcon(iconov);
        if (V==5){
            JOptionPane.showMessageDialog(this, "Lo siento perdiste");
            System.exit(1);
        }       
        else
            iniciar(); 
    }
    //Barra de progreso que finaliza el juego cuando se optengan 10 aciertos
    public void Progres(int ans){
        jProgressBar1.setValue(ans);
        if (ans == 100){
            JOptionPane.showMessageDialog(this, "Felicidades Ganaste");
            System.exit(1);
        }
        else
            iniciar();
    }
    
    
   
      

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new JButton();
        jButton2 = new JButton();
        jButton3 = new JButton();
        jButton4 = new JButton();
        jButton5 = new JButton();
        jButton6 = new JButton();
        jButton7 = new JButton();
        jButton8 = new JButton();
        jButton9 = new JButton();
        jButton10 = new JButton();
        jButton11 = new JButton();
        jButton12 = new JButton();
        jButton13 = new JButton();
        jButton14 = new JButton();
        jButton15 = new JButton();
        jButton16 = new JButton();
        jButton17 = new JButton();
        jButton18 = new JButton();
        jButton19 = new JButton();
        jButton20 = new JButton();
        jButton21 = new JButton();
        jButton22 = new JButton();
        jButton23 = new JButton();
        jButton24 = new JButton();
        jButton25 = new JButton();
        jButton26 = new JButton();
        jButton27 = new JButton();
        jLabel1 = new JLabel();
        jLabel3 = new JLabel();
        jLabe4 = new JLabel();
        jLabel4 = new JLabel();
        jLabel5 = new JLabel();
        jProgressBar1 = new JProgressBar();
        jScrollPane1 = new JScrollPane();
        jTextPane1 = new JTextPane();
        jLabel2 = new JLabel();

        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setTitle("Ahorcado");
        setAlwaysOnTop(true);
        setBounds(new Rectangle(0, 0, 0, 0));
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
        setIconImages(null);
        setMaximumSize(new Dimension(700, 650));
        setMinimumSize(new Dimension(700, 650));
        setName("Form"); // NOI18N
        setResizable(false);
        setSize(new Dimension(300, 300));
        getContentPane().setLayout(null);

        jButton1.setFont(new Font("Comic Sans MS", 0, 11)); // NOI18N
        jButton1.setText("A");
        jButton1.setName("jButton1"); // NOI18N
        jButton1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(80, 320, 50, 30);

        jButton2.setFont(new Font("Comic Sans MS", 0, 11)); // NOI18N
        jButton2.setText("B");
        jButton2.setName("jButton2"); // NOI18N
        getContentPane().add(jButton2);
        jButton2.setBounds(130, 320, 50, 30);

        jButton3.setFont(new Font("Comic Sans MS", 0, 11)); // NOI18N
        jButton3.setText("C");
        jButton3.setName("jButton3"); // NOI18N
        getContentPane().add(jButton3);
        jButton3.setBounds(180, 320, 50, 30);

        jButton4.setFont(new Font("Comic Sans MS", 0, 11)); // NOI18N
        jButton4.setText("D");
        jButton4.setName("jButton4"); // NOI18N
        getContentPane().add(jButton4);
        jButton4.setBounds(230, 320, 50, 30);

        jButton5.setFont(new Font("Comic Sans MS", 0, 11)); // NOI18N
        jButton5.setText("E");
        jButton5.setName("jButton5"); // NOI18N
        getContentPane().add(jButton5);
        jButton5.setBounds(280, 320, 50, 30);

        jButton6.setFont(new Font("Comic Sans MS", 0, 11)); // NOI18N
        jButton6.setText("F");
        jButton6.setName("jButton6"); // NOI18N
        getContentPane().add(jButton6);
        jButton6.setBounds(330, 320, 50, 30);

        jButton7.setFont(new Font("Comic Sans MS", 0, 11)); // NOI18N
        jButton7.setText("G");
        jButton7.setName("jButton7"); // NOI18N
        getContentPane().add(jButton7);
        jButton7.setBounds(380, 320, 50, 30);

        jButton8.setFont(new Font("Comic Sans MS", 0, 11)); // NOI18N
        jButton8.setText("H");
        jButton8.setName("jButton8"); // NOI18N
        getContentPane().add(jButton8);
        jButton8.setBounds(80, 350, 50, 30);

        jButton9.setFont(new Font("Comic Sans MS", 0, 11)); // NOI18N
        jButton9.setText("I");
        jButton9.setName("jButton9"); // NOI18N
        getContentPane().add(jButton9);
        jButton9.setBounds(130, 350, 50, 30);

        jButton10.setFont(new Font("Comic Sans MS", 0, 11)); // NOI18N
        jButton10.setText("J");
        jButton10.setName("jButton10"); // NOI18N
        jButton10.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton10);
        jButton10.setBounds(180, 350, 50, 30);

        jButton11.setFont(new Font("Comic Sans MS", 0, 11)); // NOI18N
        jButton11.setText("K");
        jButton11.setName("jButton11"); // NOI18N
        getContentPane().add(jButton11);
        jButton11.setBounds(230, 350, 50, 30);

        jButton12.setFont(new Font("Comic Sans MS", 0, 11)); // NOI18N
        jButton12.setText("L");
        jButton12.setName("jButton12"); // NOI18N
        getContentPane().add(jButton12);
        jButton12.setBounds(280, 350, 50, 30);

        jButton13.setFont(new Font("Comic Sans MS", 0, 11)); // NOI18N
        jButton13.setText("M");
        jButton13.setName("jButton13"); // NOI18N
        getContentPane().add(jButton13);
        jButton13.setBounds(330, 350, 50, 30);

        jButton14.setFont(new Font("Comic Sans MS", 0, 11)); // NOI18N
        jButton14.setText("N");
        jButton14.setName("jButton14"); // NOI18N
        jButton14.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                jButton14ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton14);
        jButton14.setBounds(380, 350, 50, 30);

        jButton15.setFont(new Font("Comic Sans MS", 0, 11)); // NOI18N
        jButton15.setText("O");
        jButton15.setName("jButton15"); // NOI18N
        getContentPane().add(jButton15);
        jButton15.setBounds(80, 380, 50, 30);

        jButton16.setFont(new Font("Comic Sans MS", 0, 11)); // NOI18N
        jButton16.setText("P");
        jButton16.setName("jButton16"); // NOI18N
        getContentPane().add(jButton16);
        jButton16.setBounds(130, 380, 50, 30);

        jButton17.setFont(new Font("Comic Sans MS", 0, 11)); // NOI18N
        jButton17.setText("Q");
        jButton17.setName("jButton17"); // NOI18N
        getContentPane().add(jButton17);
        jButton17.setBounds(180, 380, 50, 30);

        jButton18.setFont(new Font("Comic Sans MS", 0, 11)); // NOI18N
        jButton18.setText("R");
        jButton18.setName("jButton18"); // NOI18N
        getContentPane().add(jButton18);
        jButton18.setBounds(230, 380, 50, 30);

        jButton19.setFont(new Font("Comic Sans MS", 0, 11)); // NOI18N
        jButton19.setText("S");
        jButton19.setName("jButton19"); // NOI18N
        getContentPane().add(jButton19);
        jButton19.setBounds(280, 380, 50, 30);

        jButton20.setFont(new Font("Comic Sans MS", 0, 11)); // NOI18N
        jButton20.setText("T");
        jButton20.setName("jButton20"); // NOI18N
        getContentPane().add(jButton20);
        jButton20.setBounds(330, 380, 50, 30);

        jButton21.setFont(new Font("Comic Sans MS", 0, 11)); // NOI18N
        jButton21.setText("U");
        jButton21.setName("jButton21"); // NOI18N
        getContentPane().add(jButton21);
        jButton21.setBounds(380, 380, 50, 30);

        jButton22.setFont(new Font("Comic Sans MS", 0, 11)); // NOI18N
        jButton22.setText("V");
        jButton22.setName("jButton22"); // NOI18N
        getContentPane().add(jButton22);
        jButton22.setBounds(110, 410, 50, 30);

        jButton23.setFont(new Font("Comic Sans MS", 0, 11)); // NOI18N
        jButton23.setText("W");
        jButton23.setName("jButton23"); // NOI18N
        jButton23.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                jButton23ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton23);
        jButton23.setBounds(160, 410, 50, 30);

        jButton24.setFont(new Font("Comic Sans MS", 0, 11)); // NOI18N
        jButton24.setText("X");
        jButton24.setName("jButton24"); // NOI18N
        getContentPane().add(jButton24);
        jButton24.setBounds(210, 410, 50, 30);

        jButton25.setFont(new Font("Comic Sans MS", 0, 11)); // NOI18N
        jButton25.setText("Y");
        jButton25.setName("jButton25"); // NOI18N
        jButton25.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                jButton25ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton25);
        jButton25.setBounds(260, 410, 50, 30);

        jButton26.setFont(new Font("Comic Sans MS", 0, 11)); // NOI18N
        jButton26.setText("Z");
        jButton26.setName("jButton26"); // NOI18N
        getContentPane().add(jButton26);
        jButton26.setBounds(310, 410, 50, 30);

        jButton27.setFont(new Font("Comic Sans MS", 0, 11)); // NOI18N
        jButton27.setText("Reiniciar");
        jButton27.setName("jButton27"); // NOI18N
        jButton27.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                jButton27ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton27);
        jButton27.setBounds(210, 260, 81, 27);

        jLabel1.setName("jLabel1"); // NOI18N
        getContentPane().add(jLabel1);
        jLabel1.setBounds(490, 270, 180, 180);

        jLabel3.setName("jLabel3"); // NOI18N
        getContentPane().add(jLabel3);
        jLabel3.setBounds(490, 10, 180, 180);

        jLabe4.setFont(new Font("Comic Sans MS", 0, 18)); // NOI18N
        jLabe4.setForeground(new Color(255, 255, 255));
        jLabe4.setText("0:0");
        jLabe4.setName("jLabe4"); // NOI18N
        getContentPane().add(jLabe4);
        jLabe4.setBounds(40, 30, 50, 40);

        jLabel4.setFont(new Font("Comic Sans MS", 0, 18)); // NOI18N
        jLabel4.setForeground(new Color(255, 255, 255));
        jLabel4.setText("Score: ");
        jLabel4.setName("jLabel4"); // NOI18N
        getContentPane().add(jLabel4);
        jLabel4.setBounds(110, 20, 240, 50);

        jLabel5.setText("jLabel5");
        jLabel5.setName("jLabel5"); // NOI18N
        getContentPane().add(jLabel5);
        jLabel5.setBounds(20, 90, 180, 40);

        jProgressBar1.setName("jProgressBar1"); // NOI18N
        getContentPane().add(jProgressBar1);
        jProgressBar1.setBounds(110, 470, 280, 16);

        jScrollPane1.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane1.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);
        jScrollPane1.setName("jScrollPane1"); // NOI18N

        jTextPane1.setEditable(false);
        jTextPane1.setFont(new Font("Comic Sans MS", 0, 11)); // NOI18N
        jTextPane1.setAutoscrolls(false);
        jTextPane1.setName("jTextPane1"); // NOI18N
        jScrollPane1.setViewportView(jTextPane1);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(70, 180, 360, 40);

        jLabel2.setIcon(new ImageIcon(getClass().getResource("/Fondo.jpg"))); // NOI18N
        jLabel2.setMaximumSize(new Dimension(2147483647, 2147483647));
        jLabel2.setMinimumSize(new Dimension(800, 650));
        jLabel2.setName("jLabel2"); // NOI18N
        getContentPane().add(jLabel2);
        jLabel2.setBounds(0, 0, 1800, 800);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton27ActionPerformed(ActionEvent evt) {//GEN-FIRST:event_jButton27ActionPerformed
        // TODO add your handling code here:
        iniciar();
    }//GEN-LAST:event_jButton27ActionPerformed

    

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Ahorcado.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Ahorcado.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Ahorcado.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Ahorcado.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() { 
            @Override
            public void run() {
                new Ahorcado().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public JButton jButton1;
    private JButton jButton10;
    private JButton jButton11;
    private JButton jButton12;
    private JButton jButton13;
    private JButton jButton14;
    private JButton jButton15;
    private JButton jButton16;
    private JButton jButton17;
    private JButton jButton18;
    private JButton jButton19;
    private JButton jButton2;
    private JButton jButton20;
    private JButton jButton21;
    private JButton jButton22;
    private JButton jButton23;
    private JButton jButton24;
    private JButton jButton25;
    private JButton jButton26;
    private JButton jButton27;
    private JButton jButton3;
    private JButton jButton4;
    private JButton jButton5;
    private JButton jButton6;
    private JButton jButton7;
    private JButton jButton8;
    private JButton jButton9;
    private JLabel jLabe4;
    private JLabel jLabel1;
    private JLabel jLabel2;
    private JLabel jLabel3;
    private JLabel jLabel4;
    private JLabel jLabel5;
    private JProgressBar jProgressBar1;
    private JScrollPane jScrollPane1;
    private JTextPane jTextPane1;
    // End of variables declaration//GEN-END:variables
}
